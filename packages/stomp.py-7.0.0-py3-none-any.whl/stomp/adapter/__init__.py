"""Non-standard adapters.
"""
